print("Sample script")
